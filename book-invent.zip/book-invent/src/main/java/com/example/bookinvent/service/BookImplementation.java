package com.example.bookinvent.service;


import com.example.bookinvent.dao.repositories.BookRepository;
import com.example.bookinvent.dto.BookDto;
import com.example.bookinvent.mapper.BookMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class BookImplementation implements  BookManager{


    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private BookMapper bookMapper;

    @Override
    public BookDto getBookById(Long id) {
        return bookMapper.fromBookToBookDto(bookRepository.findById(id).get());
    }
    @Override
    public BookDto saveBook(BookDto bookDto){
    return bookMapper.fromBookToBookDto(bookRepository.save(
            bookMapper.fromBookDtoToBook(bookDto)));



    }




}

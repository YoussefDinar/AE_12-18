package com.example.bookinvent.web;


import com.example.bookinvent.dto.BookDto;
import com.example.bookinvent.service.BookManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Component;

@Component
public class BookGraphQLController {
@Autowired
    private BookManager bookManager;
@QueryMapping
    public BookDto getBookById(@Argument Long id){
    return bookManager.getBookById(id);

}

@MutationMapping
public BookDto saveBook(@Argument BookDto bookDto){

    return bookManager.saveBook(bookDto);
}


}

package com.example.bookinvent.dao.entities;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;


import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
@Entity
public class Book {
    @Id
    private Long id_book;
    private String titre;
    private String publisher;

    private Date date_publication;
    private float price;

}

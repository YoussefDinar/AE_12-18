package com.example.bookinvent;

import com.example.bookinvent.dao.entities.Book;
import com.example.bookinvent.dao.repositories.BookRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;
import java.util.List;

@SpringBootApplication
public class BookInventApplication {

    public static void main(String[] args) {

        SpringApplication.run(BookInventApplication.class, args);
    }


    @Bean
    CommandLineRunner start(BookRepository bookRepository) {
        return args -> {

            List<Book> bookList = List.of(
                    Book.builder().titre("Harry Potter").publisher("Lisa").date_publication(new Date()).
                            price(50).build(),
                    Book.builder().titre("b2").publisher("p2").date_publication(new Date()).
                            price(60).build(),
                    Book.builder().titre("b3").publisher("p3").date_publication(new Date()).
                            price(55).build(),
                    Book.builder().titre("b4").publisher("p4").date_publication(new Date()).
                            price(20).build()

            );
            bookRepository.saveAll(bookList);
        };


    }
}

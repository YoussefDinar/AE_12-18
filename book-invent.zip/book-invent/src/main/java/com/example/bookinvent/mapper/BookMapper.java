package com.example.bookinvent.mapper;

import com.example.bookinvent.dao.entities.Book;
import com.example.bookinvent.dto.BookDto;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class BookMapper {

    private ModelMapper modelMapper = new ModelMapper();

    public BookDto fromBookToBookDto(Book book){
        return  modelMapper.map(book, BookDto.class );
    }

    public Book fromBookDtoToBook(BookDto bookDto){
        return  modelMapper.map(bookDto, Book.class );
    }


}

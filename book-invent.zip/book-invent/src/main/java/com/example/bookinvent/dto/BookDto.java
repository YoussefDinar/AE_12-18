package com.example.bookinvent.dto;

import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Getter
@Setter
@Builder
@ToString
public class BookDto {
    private String titre;
    private String publisher;

    private Date date_publication;
    private float price;

}

package com.example.bookinvent.service;


import com.example.bookinvent.dto.BookDto;

public interface BookManager {
    public BookDto getBookById(Long id);
    public BookDto saveBook(BookDto bookDto);

}



